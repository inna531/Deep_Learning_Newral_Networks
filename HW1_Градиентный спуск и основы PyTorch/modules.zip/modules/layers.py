import numpy as np
from typing import List
from modules.base import Module


class Linear(Module):
    """
    Линейный слой (аффинное преобразование): y = x W^T + b

    Данный слой выполняет линейное преобразование входных данных.
    - На вход подаётся матрица размера (batch_size, in_features),
      где каждая строка — это один объект в батче.
    - Преобразование выполняется так: y = x W^T + b.
      Здесь:
        x — входной тензор,
        W — матрица весов (размером out_features × in_features),
        b — вектор сдвига длины out_features (опционален).

    Результатом является матрица той же batch_size, но с размерностью признаков out_features.
    """
    def __init__(self, in_features: int, out_features: int, bias: bool = True):
        """
        Инициализация слоя.
        :param in_features: количество входных признаков (размерность входного вектора)
        :param out_features: количество выходных признаков (размерность выходного вектора)
        :param bias: использовать ли смещение (b)

        Здесь создаются:
        - Матрица весов W размера (out_features, in_features), инициализируемая случайно
          с масштабированием 1 / sqrt(in_features).
        - Вектор смещений b размера (out_features), если bias=True.
        - Буферы для накопления градиентов grad_weight и grad_bias.
        """
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = np.random.uniform(-1, 1, (out_features, in_features)) / np.sqrt(in_features)
        self.bias = np.random.uniform(-1, 1, out_features) / np.sqrt(in_features) if bias else None

        self.grad_weight = np.zeros_like(self.weight)
        self.grad_bias = np.zeros_like(self.bias) if bias else None

    def compute_output(self, input: np.ndarray) -> np.ndarray:
        """
        Вычисляет прямой проход (forward pass).
        :param input: входной массив формы (batch_size, in_features)
        :return: выход массива формы (batch_size, out_features)

        Обычно реализация будет:
            output = input @ weight.T + bias
        где @ — матричное умножение.

        Данную реализацию нужно переписать при наследовании.
        """
        # y = x W^T + b
        out = input @ self.weight.T
        if self.bias is not None:
            out += self.bias
        return out

    def compute_grad_input(self, input: np.ndarray, grad_output: np.ndarray) -> np.ndarray:
        """
        Вычисляет градиент выходной функции по входу (backward pass по входу).
        :param input: входной массив (batch_size, in_features)
        :param grad_output: градиент функции ошибки по выходу слоя,
                            массив формы (batch_size, out_features)
        :return: градиент по входу: массив формы (batch_size, in_features)

        Смысл:
        - Используя grad_output, вычислить dL/dX.
        - Поскольку y = x W^T + b, то dL/dX = grad_output @ W.

        Обычно реализация будет:
            grad_input = grad_output @ weight
        """
        # replace with your code
        return super().compute_grad_input(input, grad_output)

    def update_grad_parameters(self, input: np.ndarray, grad_output: np.ndarray):
        """
        Вычисляет градиенты по параметрам (весам и смещению).
        :param input: входной массив формы (batch_size, in_features)
        :param grad_output: градиент по выходу (batch_size, out_features)

        Идея:
        - Накопить dL/dW и dL/dB.
        - Для веса:
              dL/dW = grad_output^T @ input
          (или эквивалентно сумма по батчу grad_output[i] * input[i]).
        - Для смещения:
              dL/dB = сумма grad_output по batch_size.

        Эти градиенты складываются с grad_weight и grad_bias, чтобы затем
        можно было применить шаг оптимизации.
        """
        # replace with your code
        super().update_grad_parameters(input, grad_output)

    def zero_grad(self):
        """
        Обнуляет накопленные градиенты grad_weight и grad_bias.
        Вызывается перед началом нового шага обучения.
        """
        self.grad_weight.fill(0)
        if self.bias is not None:
            self.grad_bias.fill(0)

    def parameters(self) -> List[np.ndarray]:
        """
        Возвращает список параметров слоя (веса и, если есть, смещение).
        Используется оптимизаторами для обновления.
        """
        if self.bias is not None:
            return [self.weight, self.bias]
        return [self.weight]

    def parameters_grad(self) -> List[np.ndarray]:
        """
        Возвращает список градиентов параметров (grad_weight, grad_bias).
        """
        if self.bias is not None:
            return [self.grad_weight, self.grad_bias]
        return [self.grad_weight]

    def __repr__(self) -> str:
        """
        Текстовое представление слоя, полезно для отладки.
        Показывает количество входных/выходных признаков и наличие bias.
        """
        out_features, in_features = self.weight.shape
        return f'Linear(in_features={in_features}, out_features={out_features}, ' \
               f'bias={not self.bias is None})'
  


class BatchNormalization(Module):
    """
    Применяет преобразование пакетной нормализации (Batch Normalization).

    BatchNorm стабилизирует распределение активаций во время обучения.
    Для каждого признака по мини-батчу вычисляются среднее и дисперсия,
    после чего данные нормализуются и (опционально) масштабируются
    и смещаются обучаемыми параметрами.
    """

    def __init__(self, num_features: int, eps: float = 1e-5, momentum: float = 0.1, affine: bool = True):
        """
        :param num_features: количество признаков (размерность входного вектора)
        :param eps: малое значение, добавляемое к дисперсии для численной стабильности
        :param momentum: коэффициент обновления бегущих (скользящих) статистик
        :param affine: использовать ли обучаемые параметры (масштаб weight и сдвиг bias)

        Основная идея:
        - На обучении статистики (mean, var) вычисляются по батчу.
        - Для инференса поддерживаются бегущие статистики (running_mean, running_var),
          которые постепенно обновляются с заданным momentum.
        """
        super().__init__()
        self.eps = eps
        self.momentum = momentum
        self.affine = affine

        # Бегущие (скользящие) статистики, используемые при инференсе
        self.running_mean = np.zeros(num_features)
        self.running_var = np.ones(num_features)

        # Параметры для тренировки γ и β
        if affine:
            self.weight = np.ones(num_features)
            self.bias = np.zeros(num_features)
            self.grad_weight = np.zeros_like(self.weight)
            self.grad_bias = np.zeros_like(self.bias)
        else:
            self.weight = None
            self.bias = None

        # Переменные, сохраняемые в forward pass (нужны для backward pass)
        self.mean = None
        self.var = None
        self.input_centered = None
        self.std_inv = None
        self.normalized = None
        self.batch_size = None

    def compute_output(self, input: np.ndarray) -> np.ndarray:
        """
        Выполняет прямой проход BatchNorm.
        :param input: массив формы (batch_size, num_features)
        :return: нормализованный массив той же формы

        Логика:
        - На обучении:
              mean = среднее по батчу
              var = дисперсия по батчу
              norm = (x - mean) / sqrt(var + eps)
          Обновляются running_mean и running_var.

        - На инференсе используется:
              norm = (x - running_mean) / sqrt(running_var + eps)

        - Если affine=True:
              output = weight * norm + bias

        Иначе output = norm.
        """
        # replace with your code
        return super().compute_output(input)

    def compute_grad_input(self, input: np.ndarray, grad_output: np.ndarray) -> np.ndarray:
        """
        Вычисляет градиент функции ошибки по входу (dL/dX).
        :param input: массив формы (batch_size, num_features)
        :param grad_output: градиент по выходу BatchNorm (batch_size, num_features)
        :return: массив формы (batch_size, num_features), градиент по входу

        Основная идея:
        - Для обратного прохода учитывается полный паттерн производных BatchNorm:
              d(norm)/d(x), d(mean)/d(x), d(var)/d(x)
        - Сначала вычисляется градиент по нормализованному входу.
        - Затем вычисляется градиент по X с учётом производных
          по mean и var, которые моделируют зависимость от всех элементов батча.
        """
        # replace with your code
        return super().compute_grad_input(input, grad_output)


    def update_grad_parameters(self, input: np.ndarray, grad_output: np.ndarray):
                """
        Вычисляет градиенты параметров γ (weight) и β (bias).
        :param input: массив формы (batch_size, num_features)
        :param grad_output: массив формы (batch_size, num_features)

        Если affine=True:
        - dL/dγ = Σ (grad_output * norm_input)
        - dL/dβ = Σ grad_output

        Градиенты суммируются по батчу и добавляются в grad_weight и grad_bias.
        """
        # replace with your code
        super().update_grad_parameters(input, grad_output)

    def zero_grad(self):
        """
        Обнуляет накопленные градиенты по параметрам γ и β.
        """
        if self.affine:
            self.grad_weight.fill(0)
            self.grad_bias.fill(0)

    def parameters(self) -> List[np.ndarray]:
        return [self.weight, self.bias] if self.affine else []

    def parameters_grad(self) -> List[np.ndarray]:
        return [self.grad_weight, self.grad_bias] if self.affine else []

    def __repr__(self) -> str:
        return f'BatchNormalization(num_features={len(self.running_mean)}, ' \
               f'eps={self.eps}, momentum={self.momentum}, affine={self.affine})'



class Dropout(Module):
    """
    Применяет операцию Dropout.

    Dropout — это регуляризующий приём, уменьшающий переобучение.
    Во время обучения случайная часть элементов входного тензора
    обнуляется с вероятностью p. Оставшиеся элементы масштабируются
    соответствующим образом, чтобы сохранить ожидаемую сумму активаций.

    Во время инференса (eval-режим) Dropout не применяется
    — данные пропускаются без изменений.
    """

    def __init__(self, p=0.5):
        """
        :param p: вероятность зануления элемента (0 ≤ p < 1)

        Чем выше p — тем сильнее регуляризация.
        Пример: p=0.5 — половина входных значений в среднем обнуляется.
        """
        super().__init__()
        assert 0 <= p < 1
        self.p = p
        self.mask = None

    def compute_output(self, input: np.ndarray) -> np.ndarray:
        """
        Выполняет прямой проход.

        :param input: массив произвольной формы
        :return: массив той же формы

        Логика:
        - В режиме обучения:
              генерируется бинарная маска M из {0,1},
              где 1 встречается с вероятностью (1 - p);
              результат: output = input * M / (1 - p)
              Масштабирование сохраняет математическое ожидание активаций.
              Маска сохраняется для backward.

        - В режиме инференса:
              output = input (без изменений)
        """
        # replace with your code
        return super().compute_output(input)

    def compute_grad_input(self, input: np.ndarray, grad_output: np.ndarray) -> np.ndarray:
        """
        Выполняет обратный проход (вычисляет dL/dX).

        :param input: массив произвольной формы
        :param grad_output: градиент по выходу Dropout (той же формы)
        :return: градиент по входу (той же формы)

        Логика:
        - Если обучение:
              dL/dX = grad_output * M / (1 - p)
              (используется та же маска, что и в forward)

        - Если инференс:
              dL/dX = grad_output (поскольку dropout не применялся)
        """
        # replace with your code
        return super().compute_grad_input(input, grad_output)

    def __repr__(self) -> str:
        return f'Dropout(p={self.p})'



class Sequential(Module):
    """
    Контейнер для последовательного применения модулей.

    Sequential упрощает построение нейросети, позволяя
    последовательно объединять несколько слоёв.
    Каждый следующий модуль получает на вход результат
    предыдущего. Таким образом, структура сети задаётся
    простой последовательностью слоёв.

    Работает как PyTorch nn.Sequential:
        y = m_n(...(m_2(m_1(x))))
    """
    def __init__(self, *args):
        """
        :param args: произвольное количество модулей (слоёв), 
                     применяемых один за другим

        Все переданные модули сохраняются во внутреннем списке.
        """
        super().__init__()
        self.modules = list(args)
        self.saved_inputs = []

    def add(self, module: Module):
        """Add module at the end"""
        self.modules.append(module)

    def compute_output(self, input: np.ndarray) -> np.ndarray:
         """
        Выполняет прямой проход через все модули по очереди.

        :param input: массив подходящего размера для первого слоя
        :return: выход последнего слоя

        Логика:
        - Последовательно передать выход каждого слоя
          на вход следующему.
        - Результат последнего слоя — итоговый результат.

        Пример:
            x = input
            for module in self.modules:
                x = module.compute_output(x)
            return x
        """
        # replace with your code
        return super().compute_output(input)

    def compute_grad_input(self, input: np.ndarray, grad_output: np.ndarray) -> np.ndarray:
        """
        Вычисляет обратный проход (dL/dX) через все модули в обратном порядке.

        :param input: массив подходящего размера для первого слоя
        :param grad_output: градиент по выходу последнего слоя 
        :return: градиент по входу первого слоя

        Логика:
        - Прямой проход: нужно сохранить промежуточные значения,
          чтобы передать их в backward соответствующим слоям.
          (обычно это делает реализация выше по уровню)
        - Обратный проход:
              передавать градиент в слои в обратном порядке
              (от последнего к первому).
              Каждый слой возвращает градиент по своему входу.
        """
        grad = grad_output

        for i in reversed(range(len(self.modules))):
            module = self.modules[i]
            prev_input = self.saved_inputs[i]

            # grad_output для этой слоя = grad
            grad_input = module.compute_grad_input(prev_input, grad)
            module.update_grad_parameters(prev_input, grad)

            grad = grad_input

        return grad
    

    def __getitem__(self, item):
        """
        Позволяет получить модуль по индексу: seq[i]
        """
        return self.modules[item]

    def __len__(self):
        """Return number of modules"""
        return len(self.modules)

    def train(self):
        for module in self.modules:
            module.train()

    def eval(self):
        for module in self.modules:
            module.eval()

    def zero_grad(self):
        for module in self.modules:
            module.zero_grad()

    def parameters(self) -> List[np.ndarray]:
        """Collect parameters from all modules"""
        return [parameter 
                for module in self.modules 
                for parameter in module.parameters()]

    def parameters_grad(self) -> List[np.ndarray]:
        """Collect parameter gradients from all modules"""
        return [grad
                for module in self.modules
                for grad in module.parameters_grad()]

    def __repr__(self) -> str:
        repr_str = 'Sequential(\n'
        for module in self.modules:
            repr_str += ' ' * 4 + repr(module) + '\n'
        repr_str += ')'
        return repr_str