import numpy as np
from typing import Tuple
from modules.base import Module, Optimizer


class SGD(Optimizer):
    """
    Оптимизатор, реализующий стохастический градиентный спуск (SGD)
    с использованием импульса (momentum).
    """

    def __init__(self, module: Module, lr: float = 1e-2,
                 momentum: float = 0.0, weight_decay: float = 0.0):
        """
        :param module: нейросеть (или контейнер), содержащая параметры
        :param lr: скорость обучения — коэффициент изменения параметров
        :param momentum: коэффициент импульса (обычно от 0.0 до 0.9+);
                         помогает сглаживать обновления и избегать колебаний
        :param weight_decay: L2-регуляризация (штраф на большие веса),
                             применяется как дополнительное изменение градиента
        """
        super().__init__(module)
        self.lr = lr
        self.momentum = momentum
        self.weight_decay = weight_decay

    def step(self):
        """
        Выполняет один шаг обновления параметров:

        Алгоритм:
        1) Получаем все параметры и их градиенты.
        2) Инициализируем момент (m), если нет:
           m имеет ту же форму, что и параметр, и накапливает
           экспоненциально взвешенные прошлые градиенты.
        3) Для каждого параметра:
            - При weight_decay добавляем L2-пенальти: grad += weight_decay * param
            - Обновляем момент:
                m = momentum * m + grad
            - Обновляем параметр:
                param = param - lr * m

        Важно: используем операции in-place, чтобы обновлять сами массивы параметров,
        а не их копии.
        """
        parameters = self.module.parameters()
        gradients = self.module.parameters_grad()

        # Инициализируем массивы накопленного импульса, если их нет
        if 'm' not in self.state:
            self.state['m'] = [np.zeros_like(param) for param in parameters]
        
        # Обновляем каждый параметр
        for param, grad, m in zip(parameters, gradients, self.state['m']):
            # YOUR CODE HERE
            # Подсказка: нужен in-place update m и param
            # используйте np.add(..., out=m/v) для in-place
            #
            # 1) добавляем L2-штраф (если используется)
            # 2) обновляем импульс: m = momentum * m + grad
            # 3) обновляем параметр: param -= lr * m
            #
            # Пример структуры (НЕ ГОТОВЫЙ КОД):
            # if self.weight_decay != 0:
            #     grad = grad + self.weight_decay * param
            #
            # m = self.momentum * m + grad
            # param -= self.lr * m
            pass



class Adam(Optimizer):
    """
    Оптимизатор Adam (Adaptive Moment Estimation).

    Adam адаптирует шаг обучения для каждого параметра,
    используя экспоненциальные средние:
        - первого момента   m  (оценка среднего градиента)
        - второго момента   v  (оценка среднего квадратов градиента)
    """

    def __init__(self, module: Module, lr: float = 1e-3,
                 betas: Tuple[float, float] = (0.9, 0.999),
                 eps: float = 1e-8, weight_decay: float = 0.0):
        """
        :param module: нейросеть, содержащая параметры
        :param lr: скорость обучения
        :param betas: коэффициенты экспоненциального сглаживания
                      (beta1 — для первого момента, beta2 — для второго момента)
        :param eps: малое число для предотвращения деления на ноль
        :param weight_decay: L2-регуляризация
        """
        super().__init__(module)
        self.lr = lr
        self.beta1 = betas[0]
        self.beta2 = betas[1]
        self.eps = eps
        self.weight_decay = weight_decay

    def step(self):
        """
        Выполняет один шаг обновления Adam:

        1) Инициализируем:
            - m (первый момент)     — усреднение градиентов
            - v (второй момент)     — усреднение квадратов градиентов
            - t (номер шага)
        2) Для каждого параметра:
            - добавляем L2-штраф к градиенту
            - обновляем моменты:
                m = beta1 * m + (1 - beta1) * grad
                v = beta2 * v + (1 - beta2) * grad^2
            - bias-correction:
                m_hat = m / (1 - beta1^t)
                v_hat = v / (1 - beta2^t)
            - обновляем параметр:
                param -= lr * m_hat / (sqrt(v_hat) + eps)

        Все обновления должны быть in-place, чтобы менять сами параметры.
        """
        parameters = self.module.parameters()
        gradients = self.module.parameters_grad()

        # Инициализируем хранилище, если нет
        if 'm' not in self.state:
            self.state['m'] = [np.zeros_like(param) for param in parameters]  # first moment
            self.state['v'] = [np.zeros_like(param) for param in parameters]  # second moment
            self.state['t'] = 0

        self.state['t'] += 1
        t = self.state['t']

        for param, grad, m, v in zip(parameters, gradients, self.state['m'], self.state['v']):
            # YOUR CODE HERE
            # Подсказка: используйте np.add(..., out=m/v) для in-place
            #
            # 1) L2-штраф
            # if self.weight_decay != 0:
            #     grad = grad + self.weight_decay * param
            #
            # 2) обновление моментов:
            # m = beta1 * m + (1 - beta1) * grad
            # v = beta2 * v + (1 - beta2) * grad**2
            #
            # 3) bias-correction:
            # m_hat = m / (1 - beta1**t)
            # v_hat = v / (1 - beta2**t)
            #
            # 4) update:
            # param -= lr * m_hat / (sqrt(v_hat) + eps)
            pass