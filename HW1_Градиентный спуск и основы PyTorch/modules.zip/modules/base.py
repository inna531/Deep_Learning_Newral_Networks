import numpy as np
from abc import ABC, abstractmethod
from typing import List


"""
This assignment is inspired by a similar task
from Deep Vision and Graphics course taught in YSDA
https://github.com/yandexdataschool/deep_vision_and_graphics/tree/fall21/homework01
"""


class Module(ABC):
    """
    Базовый класс для всех модулей нейронной сети
    """
    def __init__(self):
        self.output = None
        self.training = True

    @abstractmethod
    def compute_output(self, input: np.ndarray) -> np.ndarray:
        """
        Вычислить выход при прямом проходе, т.е. y = f(x)
        :param input: вход модуля (x)
        :return: выход модуля (y)
        """
        raise NotImplementedError

    @abstractmethod
    def compute_grad_input(self, input: np.ndarray, grad_output: np.ndarray) -> np.ndarray:
        """
        Вычислить градиент ошибки по входу, т.е. dl/dx = dl/df * df/dx
        :param input: вход модуля (x)
        :param grad_output: градиент ошибки по выходу (dl/df)
        :return: градиент ошибки по входу (dl/dx)
        """
        raise NotImplementedError

    def update_grad_parameters(self, input: np.ndarray, grad_output: np.ndarray):
        """
        Обновить градиент ошибки по параметрам, т.е. dl/dw = dl/df * df/dw
        :param input: вход модуля (x)
        :param grad_output: градиент ошибки по выходу (dl/df)
        """
        pass

    def __call__(self, input: np.ndarray) -> np.ndarray:
        """
        Алиас для метода forward
        :param input: вход модуля
        :return: выход модуля
        """
        return self.forward(input)

    def forward(self, input: np.ndarray) -> np.ndarray:
        """
        Прямой проход через модуль
        :param input: вход модуля
        :return: выход модуля
        """
        self.output = self.compute_output(input)
        return self.output

    def backward(self, input: np.ndarray, grad_output: np.ndarray) -> np.ndarray:
        """
        Обратный проход через модуль
        :param input: вход модуля
        :param grad_output: градиент ошибки по выходу
        :return: градиент ошибки по входу
        """
        grad_input = self.compute_grad_input(input, grad_output)
        self.update_grad_parameters(input, grad_output)
        return grad_input

    def train(self):
        """ Переключить модуль в режим обучения """
        self.training = True

    def eval(self):
        """ Переключить модуль в режим инференса (оценки)"""
        self.training = False

    def zero_grad(self):
        """Обнулить градиенты модуля"""
        pass

    def parameters(self) -> List[np.ndarray]:
        """Получить список всех обучаемых параметров"""
        return []

    def parameters_grad(self) -> List[np.ndarray]:
        """Получить список всех градиентов обучаемых параметров"""
        return []

    def __repr__(self) -> str:
        """Функция текстового представления (для печати)"""
        return f'{self.__class__.__name__}()'


class Criterion(ABC):
    """
    Базовый класс для всех функций потерь (лоссов)
    """
    def __init__(self):
        self.output = None

    @abstractmethod
    def compute_output(self, input: np.ndarray, target: np.ndarray) -> float:
        """
        Вычислить значение функции потерь, т.е. l(f, y)
        :param input: предсказания нейронной сети (f)
        :param target: истинные целевые значения (y)
        :return: значение функции потерь (l(f, y))
        """
        raise NotImplementedError

    @abstractmethod
    def compute_grad_input(self, input: np.ndarray, target: np.ndarray) -> np.ndarray:
        """
        Вычислить градиент функции потерь по входу, т.е. dl/df
        :param input: предсказания нейронной сети (f)
        :param target: истинные целевые значения (y)
        :return: градиент функции потерь по входу (dl/df)
        """
        raise NotImplementedError

    def __call__(self, input: np.ndarray, target: np.ndarray) -> float:
        """
        Синоним для метода forward
        :param input: предсказания нейронной сети
        :param target: истинные значения
        :return: значение функции потерь
        """
        return self.forward(input, target)

    def forward(self, input: np.ndarray, target: np.ndarray) -> float:
        """
        Прямой проход через критерий (вычисление потерь)
        :param input: предсказания нейронной сети
        :param target: истинные значения
        :return: значение функции потерь
        """
        self.output = self.compute_output(input, target)
        return self.output

    def backward(self, input: np.ndarray, target: np.ndarray) -> np.ndarray:
        """
        Обратный проход через критерий
        :param input: предсказания нейронной сети
        :param target: истинные значения
        :return: градиент функции потерь по входу
        """
        grad_input = self.compute_grad_input(input, target)
        return grad_input

    def __repr__(self) -> str:
        """
        Функция текстового представления
        """
        return f'{self.__class__.__name__}()'


class Optimizer(ABC):
    """
    Базовый класс для всех оптимизаторов
    """
    def __init__(self, module: Module):
        """
        :param module: нейронная сеть, содержащая параметры, которые нужно оптимизировать
        """
        self.module = module
        self.state = {}  # текущее состояние оптимизатора

    def zero_grad(self):
        """Обнулить градиенты параметров"""
        self.module.zero_grad()

    @abstractmethod
    def step(self):
        """Выполнить один шаг оптимизации"""
        raise NotImplementedError
