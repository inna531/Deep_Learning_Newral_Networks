import numpy as np
from modules.base import Criterion
from modules.activations import LogSoftmax


class MSELoss(Criterion):
    """
    Функция ошибки MSE (Mean Squared Error) — среднеквадратичная ошибка.

    Используется для задач регрессии.
    Определяется как среднее значение квадрата разности
    между предсказаниями и целевыми значениями.

    ℓ(f,y) = 1/(B*N) * Σ (f_ij − y_ij)^2
    """
    def compute_output(self, input: np.ndarray, target: np.ndarray) -> float:
        """
        Вычисляет значение функции потерь MSE.

        :param input: массив предсказаний (batch_size, *)
        :param target: массив целевых значений (batch_size, *)
        :return: скаляр — значение ошибки

        Формула:
            loss = mean( (input - target)^2 )
        """
        assert input.shape == target.shape, 'input и target должны иметь одинаковую форму'
        # your code here (посчитать loss, учитывая B, N)
        return super().compute_output(input, target)

    def compute_grad_input(self, input: np.ndarray, target: np.ndarray) -> np.ndarray:
        """
        Вычисляет градиент функции MSE по входу (input).

        :param input: массив предсказаний (batch_size, *)
        :param target: массив целевых значений (batch_size, *)
        :return: массив градиента (batch_size, *), такой же по форме

        Формула:
            dLoss/dInput = 2 * (input - target) / batch_size
        """
        assert input.shape == target.shape, 'input и target должны иметь одинаковую форму'
        # your code here
        return super().compute_grad_input(input, target)


class CrossEntropyLoss(Criterion):
    """
    Функция ошибки перекрестной энтропии (Cross-Entropy) по логитам.

    Используется для задач классификации.
    Принимает на вход "сырые" логиты (до Softmax).
    Внутри применяется LogSoftmax.

    ℓ(f,y) = −1/B * Σ log softmax(f_i)[y_i]
    """
    def __init__(self):
        """
        Инициализация: внутри создаём слой LogSoftmax,
        чтобы вычислить log-вероятность.
        """
        super().__init__()
        self.log_softmax = LogSoftmax()

    def compute_output(self, input: np.ndarray, target: np.ndarray) -> float:
        """
        Вычисляет значение функции потерь.

        :param input: логиты (batch_size, num_classes)
                      — необработанные выходы модели
        :param target: метки классов (batch_size,)
                       — индекс правильного класса
        :return: скаляр — значение ошибки

        Формула:
            Пусть log_p = LogSoftmax(input)
            loss = -mean( log_p[i, target[i]] )
        """
        # your code here
        return super().compute_output(input, target)

    def compute_grad_input(self, input: np.ndarray, target: np.ndarray) -> np.ndarray:
        """
        Вычисляет градиент функции Cross-Entropy по логитам.

        :param input: логиты (batch_size, num_classes)
        :param target: метки классов (batch_size,)
        :return: массив градиента (batch_size, num_classes)

        Для LogSoftmax + CrossEntropy известный градиент:
            grad[i] = p - y_one_hot
        где p = Softmax(input),
            y_one_hot — one-hot вектор для целевого класса.

        То есть:
            grad[i, target[i]] -= 1
            grad /= batch_size
        """
        # your code here
        # Подсказка:
        #     log_probs - это выход LogSoftmax
        #     probs = np.exp(log_probs)
        return super().compute_output(input, target)