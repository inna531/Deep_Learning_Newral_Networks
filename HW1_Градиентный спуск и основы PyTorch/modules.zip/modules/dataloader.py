import numpy as np


class DataLoader(object):
    """
    Инструмент для перемешивания данных и формирования мини-батчей.

    DataLoader позволяет итерироваться по данным партиями (батчами),
    автоматически формируя пары (X_batch, y_batch).
    Поддерживает опциональное перемешивание данных перед каждой эпохой.
    """

    def __init__(self, X, y, batch_size=1, shuffle=False):
        """
        :param X: массив признаков (shape: [N, ...])
        :param y: массив целевых значений (shape: [N, ...])
        :param batch_size: размер мини-батча
        :param shuffle: перемешивать ли данные перед началом итерации

        Условия:
        - X и y должны содержать одинаковое число примеров (N).
        """
        assert X.shape[0] == y.shape[0], "X and y must have same num samples"
        self.X = X
        self.y = y
        self.batch_size = batch_size
        self.shuffle = shuffle
        self.batch_id = 0       # Индекс текущего батча в эпохе
        self.idx = None         # Индексы выборки (перемешанные или по порядку)

    def __len__(self) -> int:
        """
        :return: число батчей за одну эпоху
        """
        return int(np.ceil(self.num_samples() / self.batch_size))

    def num_samples(self) -> int:
        """
        :return: общее число примеров в датасете
        """
        return self.X.shape[0]

    def __iter__(self):
        """
        Подготавливает DataLoader к итерации по данным.

        Логика:
        - Сбрасываем счётчик батчей.
        - Если shuffle=True, перемешиваем индексы.
        - Иначе — оставляем их по порядку.

        :return: self, чтобы объект стал итерируемым
        """
        self.batch_id = 0
        if self.shuffle:
            self.idx = np.random.permutation(self.num_samples())
        else:
            self.idx = np.arange(self.num_samples())
        return self

    def __next__(self):
        """
        Формирует и возвращает следующий батч — кортеж (X_batch, y_batch).

        :return: (x_batch, y_batch)

        Логика:
        - Если закончились батчи → StopIteration.
        - Иначе:
            * вычисляем границы батча,
            * выбираем соответствующие элементы из X и y.

        Примечание:
        batch_id увеличивается при каждом вызове.
        """
        if self.batch_id >= len(self):
            raise StopIteration

        start = self.batch_id * self.batch_size
        end = min(start + self.batch_size, self.num_samples())
        batch_idx = self.idx[start:end]

        self.batch_id += 1

        return self.X[batch_idx], self.y[batch_idx]